package contact;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;


@Configuration
@ComponentScan
public class ContactConfig {
//    @Bean
//    public ContactRepository contactRepository() {
//        return new ContactRepository();
//    }

//    @Bean
//    public ContactService contactService(ContactRepository contactRepository) {
//        return new ContactServiceImpl(contactRepository);
//    }
}



