package contact;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Controller
public class ContactController {

    private List<Contact> contacts = new ArrayList<>();

    @ModelAttribute("contact")
    public Contact contact() {
        return new Contact();
    }


    @GetMapping("/addContact")
    public String showContactForm(Model model) {
        model.addAttribute("contacts", contacts);
        return "contactForm";
    }

    @PostMapping("/addContact")
    public String submitContactForm(
            @ModelAttribute("contact") @Valid Contact contact,
            BindingResult bindingResult,
            Model model) {
        if (!bindingResult.hasErrors()) {
            contacts.add(contact);
            model.addAttribute("contacts", contacts);
            model.addAttribute("contact", new Contact()); // 清空表单
        }
        return "contactForm";
    }

    @GetMapping("/contacts")
    public String showContacts(Model model) {
        model.addAttribute("contacts", contacts);
        return "contactForm";
    }
}
